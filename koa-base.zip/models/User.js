const { Sequelize, DataTypes } = require('sequelize')
const seq = require('../utils/seq')

// Icon 模型
const User = seq.define('user', {
  id: {
    type: DataTypes.UUID,
    allowNull: false,
    primaryKey: true,
    defaultValue: Sequelize.UUIDV4,
    comment: 'uuid'
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    comment: '用户名'
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
    comment: '密码'
  },
  nickname: {
    type: DataTypes.STRING,
    allowNull: false,
    comment: '用户名'
  },
  remark: {
    type: DataTypes.STRING,
    allowNull: true,
    defaultValue: '',
    comment: '用户备注'
  }
}, {
  freezeTableName: true
})

module.exports = User
